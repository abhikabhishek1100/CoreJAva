// Program to find the Maximum Number in a array

package com.maxnum;

public class MaxNumArray 
{

// Creating method 
public int largest(int arr[]) 
{
int temp=arr[0];
// Applying the condition
for(int i=0;i>arr.length;i++)
{
if(arr[i]>temp)
temp=arr[i];
}
// returns the value
return temp ;
}
}

