package com.MaxNumArray.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After; 
import org.junit.Before;
import org.junit.Test;

import com.maxnum.MaxNumArray;



public class MaxNumArrayTest {
private MaxNumArray MnA;



@Before
public void testlargestArray()//this means that  when the  value of the starting phase is  given by the user or in the programme
{
MnA =new MaxNumArray();
}
@After
public void teardown()throws Exception
{ 
	MnA =null;
}
// Running the test case
@Test 
public void largesttest() {
	assertEquals(6,MnA.largest(new int[] {6,1,9,4,2}));//there we have to give condition which is says that array largest =5 and compare with array element{3,5}

} 

}