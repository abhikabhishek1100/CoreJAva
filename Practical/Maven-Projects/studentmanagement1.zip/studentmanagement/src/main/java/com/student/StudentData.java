package com.student;
import jakarta.persistence.*;

@Entity
@Table(name = "student")
 
//POJO class
public class StudentData {
 
	//primary key is Id
    @Id 
    // giving table name
    @Column(name = "studentId")
    private int id;
    private String firstName;
    private String lastName;
    private int age;
    @Column(name = "address") 
    private String address;
    private String course;
    public int getId()
    { 
    	return id; 
    }
 
    public void setId(int id)
    { 
    	this.id = id;
    }
 
    public String getStudentfirstName() 
    {
    	return firstName; 
    }
 
    public void setStudentfirstName(String firstName)
    {
        this.firstName = firstName;
    }
 
    public String getStudentlastname() 
    { 
    	return lastName;
    }
 
    public void setStudentlastname(String lastName)
    {
        this.lastName = lastName;
    }
    public int getAge()
    { 
    	return age; 
    }
 
    public void setAge(int age)
    { 
    	this.age = age;
    }
    public String getAddress()
    {
    	return address; 
    }
 
    public void setAddress(String address)
    {
        this.address = address;
    }
    public String getCourse() 
    {
    	return course; 
    }
 
    public void setCourse(String course)
    {
        this.course = course;
    }
}

