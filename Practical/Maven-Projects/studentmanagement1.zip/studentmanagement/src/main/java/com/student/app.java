package com.student;

	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.cfg.Configuration;

	import com.student.StudentData;

     public class app {
        public static void main(String[] args) 
	{ 
        // Create Configuration
	   Configuration configuration = new Configuration();
	  configuration.configure("hibernate.cfg.xml");
      configuration.addAnnotatedClass(StudentData.class);
		 
	 // Create Session Factory
  SessionFactory sessionFactory = configuration.buildSessionFactory();
		 
      // Initialize Session Object
      Session session =  sessionFactory.openSession();
		 
		StudentData st1 = new StudentData();
		StudentData st2 = new StudentData();
		StudentData st3=new StudentData();
		StudentData st4= new StudentData();
		 
     st1.setId(1);
	 st1.setStudentfirstName("Abhishek");
	 st1.setStudentlastname("SIngh");
     st1.setAddress("noida");
     st1.setAge(18);
     st1.setCourse("Btech");
     
     st2.setId(2);
     st2.setStudentfirstName("sumit");
     st2.setStudentlastname("sharma");
     st2.setAddress("greater noida");
     st2.setAge(19);
     st2.setCourse("Bsc");
     
     st3.setId(3);
     st3.setStudentfirstName("Shubham");
     st3.setStudentlastname("Pandey");
     st3.setAddress("Delhi");
     st3.setAge(20);
     st3.setCourse("Bcom");
     
     
		 
	session.beginTransaction();
		 
	 // Here we have used
    // save() method of JPA
    session.save(st1);
    session.save(st2);
    session.save(st3);

		 
    session.getTransaction().commit();
				
			}
}


